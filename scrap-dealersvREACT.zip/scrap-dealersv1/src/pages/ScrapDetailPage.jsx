import React, { useState } from 'react';
import {
  ArrowLeft,
  MapPin,
  Phone,
  Mail,
  Star,
  MessageCircle,
  ShoppingCart,
  Calendar,
  Weight,
  Package,
  Truck,
  Shield,
  User,
  Eye,
  Heart,
  Share2,
  AlertTriangle,
  ChevronRight
} from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import copper from '../assets/copper.jpg'

const ScrapDetailPage = ({ scrapItem, onBack, onInquire, onPurchase }) => {
  const [selectedImage, setSelectedImage] = useState(0);
  const [quantity, setQuantity] = useState(1);
  const [isFavorited, setIsFavorited] = useState(false);

  // Sample data - replace with actual props
  const defaultScrapItem = {
    id: 1,
    title: "High Purity Copper Wire Scrap",
    category: "Metals",
    subCategory: "Copper",
    price: 450,
    priceUnit: "per kg",
    availableQuantity: 2500,
    minQuantity: 100,
    condition: "Excellent",
    description: "Premium-grade copper wire scrap from industrial electrical installations. 99.9% pure copper with PVC insulation removed. Material has been thoroughly cleaned and sorted for optimal recycling efficiency. Suitable for smelting and manufacturing applications.",
    location: "Mumbai, Maharashtra",
    images: [
      copper,
      copper,
    ],
    postedDate: "2024-12-15",
    seller: {
      id: 101,
      name: "Rajesh Kumar",
      businessName: "Kumar Scrap Trading",
      rating: 4.7,
      totalReviews: 156,
      memberSince: "2022",
      verified: true,
      phone: "+91 98765 43210",
      email: "rajesh@kumarscrap.com",
      location: "Andheri East, Mumbai",
      avatar: "/api/placeholder/100/100"
    },
    specifications: {
      purity: "99.9%",
      wireGauge: "Mixed (12-16 AWG)",
      packaging: "Bundled (50kg bundles)",
      origin: "Industrial electrical",
      moistureContent: "<0.5%",
      contamination: "Negligible"
    },
    delivery: {
      available: true,
      freeDeliveryAbove: 1000,
      estimatedDays: "3-5 business days",
      charges: 50
    },
    gradient: "from-orange-500 to-amber-600"
  };

  const item = scrapItem || defaultScrapItem;

  const handleQuantityChange = (value) => {
    const newQuantity = Math.max(item.minQuantity, Math.min(item.availableQuantity, value));
    setQuantity(newQuantity);
  };

  const navigate = useNavigate()
  const handleBack = () => {
    navigate('/buyer');
    window.scrollTo(0, 0);
  };


  const totalPrice = quantity * item.price;
  const deliveryCharge = quantity * item.price >= item.delivery.freeDeliveryAbove ? 0 : item.delivery.charges;

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-blue-900 to-emerald-900">
      {/* Header */}
      <div className="bg-slate-900/80 backdrop-blur-md border-b border-slate-700/50">
        <div className="max-w-7xl mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <button
              onClick={handleBack}
              className="flex items-center text-slate-300 hover:text-white transition-colors"
            >
              <ArrowLeft className="w-5 h-5 mr-2" />
              Back to Listings
            </button>
            <div className="flex items-center space-x-3">
              <button
                onClick={() => setIsFavorited(!isFavorited)}
                className={`p-2 rounded-lg transition-colors ${isFavorited ? 'text-red-400 bg-red-500/20' : 'text-slate-400 hover:text-red-400 hover:bg-red-500/10'
                  }`}
              >
                <Heart className={`w-5 h-5 ${isFavorited ? 'fill-current' : ''}`} />
              </button>
              <button className="p-2 rounded-lg text-slate-400 hover:text-white hover:bg-slate-700/50 transition-colors">
                <Share2 className="w-5 h-5" />
              </button>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Left Column - Images and Details */}
          <div className="lg:col-span-2 space-y-6">
            {/* Image Gallery */}
            <div className="bg-slate-800/50 backdrop-blur-sm border border-slate-700/50 rounded-2xl overflow-hidden hover:border-emerald-500/30 transition-all">
              {/* Gradient bar */}
              <div className={`h-2 bg-gradient-to-r ${item.gradient}`}></div>

              {/* Main Image Preview */}
              <div className="aspect-[4/3] bg-slate-700/30 flex items-center justify-center">
                <img
                  src={item.images[selectedImage]}
                  alt={`Selected Image ${selectedImage + 1}`}
                  className="object-cover w-full h-full"
                />
              </div>

              {/* Thumbnail Buttons */}
              <div className="p-4">
                <div className="flex space-x-2 overflow-x-auto">
                  {item.images.map((img, index) => (
                    <button
                      key={index}
                      onClick={() => setSelectedImage(index)}
                      className={`flex-shrink-0 w-16 h-16 rounded-lg overflow-hidden border-2 transition-colors ${selectedImage === index
                        ? 'border-emerald-500'
                        : 'border-slate-600 hover:border-slate-500'
                        } bg-slate-700/50`}
                    >
                      <img
                        src={img}
                        alt={`Thumbnail ${index + 1}`}
                        className="object-cover w-full h-full"
                      />
                    </button>
                  ))}
                </div>
              </div>
            </div>


            {/* Item Details */}
            <div className="bg-slate-800/50 backdrop-blur-sm border border-slate-700/50 rounded-2xl p-6 hover:border-emerald-500/30 transition-all">
              <div className="flex items-start justify-between mb-4">
                <div>
                  <h1 className="text-2xl font-bold text-white mb-2">{item.title}</h1>
                  <div className="flex items-center space-x-4 text-sm text-slate-300">
                    <span className="bg-emerald-500/20 text-emerald-300 px-3 py-1 rounded-lg font-medium">
                      {item.category}
                    </span>
                    <span>{item.subCategory}</span>
                    <div className="flex items-center">
                      <MapPin className="w-4 h-4 mr-1 text-slate-400" />
                      {item.location}
                    </div>
                  </div>
                </div>
                <div className="text-right">
                  <div className="text-3xl font-bold text-emerald-400">₹{item.price}</div>
                  <div className="text-sm text-slate-400">{item.priceUnit}</div>
                </div>
              </div>

              {/* Key Stats */}
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
                <div className="bg-slate-700/50 rounded-xl p-4 text-center border border-slate-600/50">
                  <Weight className="w-6 h-6 text-emerald-400 mx-auto mb-2" />
                  <div className="text-sm text-slate-300">Available</div>
                  <div className="font-semibold text-white">{item.availableQuantity} kg</div>
                </div>
                <div className="bg-slate-700/50 rounded-xl p-4 text-center border border-slate-600/50">
                  <Package className="w-6 h-6 text-emerald-400 mx-auto mb-2" />
                  <div className="text-sm text-slate-300">Min Order</div>
                  <div className="font-semibold text-white">{item.minQuantity} kg</div>
                </div>
                <div className="bg-slate-700/50 rounded-xl p-4 text-center border border-slate-600/50">
                  <Shield className="w-6 h-6 text-emerald-400 mx-auto mb-2" />
                  <div className="text-sm text-slate-300">Condition</div>
                  <div className="font-semibold text-white">{item.condition}</div>
                </div>
                <div className="bg-slate-700/50 rounded-xl p-4 text-center border border-slate-600/50">
                  <Calendar className="w-6 h-6 text-emerald-400 mx-auto mb-2" />
                  <div className="text-sm text-slate-300">Posted</div>
                  <div className="font-semibold text-white">{new Date(item.postedDate).toLocaleDateString()}</div>
                </div>
              </div>

              {/* Description */}
              <div className="mb-6">
                <h3 className="text-lg font-semibold text-white mb-3">Description</h3>
                <p className="text-slate-300 leading-relaxed">{item.description}</p>
              </div>

              {/* Specifications */}
              <div className="mb-6">
                <h3 className="text-lg font-semibold text-white mb-3">Specifications</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {Object.entries(item.specifications).map(([key, value]) => (
                    <div key={key} className="flex justify-between py-2 border-b border-slate-700">
                      <span className="text-slate-400 capitalize">{key.replace(/([A-Z])/g, ' $1')}</span>
                      <span className="font-medium text-white">{value}</span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Delivery Info */}
              <div className="bg-emerald-900/30 rounded-xl p-4 border border-emerald-800/50">
                <div className="flex items-center mb-2">
                  <Truck className="w-5 h-5 text-emerald-400 mr-2" />
                  <h4 className="font-semibold text-emerald-300">Delivery Information</h4>
                </div>
                <div className="text-sm text-emerald-200 space-y-1">
                  <div>Delivery available in {item.delivery.estimatedDays}</div>
                  <div>Free delivery on orders above ₹{item.delivery.freeDeliveryAbove}</div>
                  <div>Standard delivery charges: ₹{item.delivery.charges}</div>
                </div>
              </div>
            </div>
          </div>

          {/* Right Column - Seller Info and Purchase */}
          <div className="space-y-6">
            {/* Seller Information */}
            <div className="bg-slate-800/50 backdrop-blur-sm border border-slate-700/50 rounded-2xl p-6 hover:border-emerald-500/30 transition-all">
              <h3 className="text-lg font-semibold text-white mb-4">Seller Information</h3>

              <div className="flex items-start space-x-4 mb-4">
                <div className="w-16 h-16 rounded-full bg-gradient-to-r from-blue-500 to-cyan-600 flex items-center justify-center text-xl font-bold">
                  {item.seller.name.charAt(0)}
                </div>
                <div className="flex-1">
                  <div className="flex items-center mb-1">
                    <h4 className="font-semibold text-white">{item.seller.name}</h4>
                    {item.seller.verified && (
                      <Shield className="w-4 h-4 text-emerald-400 ml-2" />
                    )}
                  </div>
                  <p className="text-slate-400 text-sm mb-2">{item.seller.businessName}</p>
                  <div className="flex items-center mb-2">
                    <div className="flex items-center">
                      {[...Array(5)].map((_, i) => (
                        <Star
                          key={i}
                          className={`w-4 h-4 ${i < Math.floor(item.seller.rating) ? 'text-yellow-400 fill-current' : 'text-slate-600'
                            }`}
                        />
                      ))}
                    </div>
                    <span className="text-sm text-slate-400 ml-2">
                      {item.seller.rating} ({item.seller.totalReviews} reviews)
                    </span>
                  </div>
                  <p className="text-xs text-slate-500">Member since {item.seller.memberSince}</p>
                </div>
              </div>

              <div className="space-y-3 mb-4">
                <div className="flex items-center text-sm text-slate-400">
                  <MapPin className="w-4 h-4 mr-2 text-slate-500" />
                  {item.seller.location}
                </div>
                <div className="flex items-center text-sm text-slate-400">
                  <Phone className="w-4 h-4 mr-2 text-slate-500" />
                  {item.seller.phone}
                </div>
                <div className="flex items-center text-sm text-slate-400">
                  <Mail className="w-4 h-4 mr-2 text-slate-500" />
                  {item.seller.email}
                </div>
              </div>

              <button className="w-full bg-slate-700/50 hover:bg-slate-700/70 text-white py-2 px-4 rounded-lg transition-colors flex items-center justify-center border border-slate-600/50">
                <Eye className="w-4 h-4 mr-2" />
                View Profile
              </button>
            </div>

            {/* Purchase/Inquiry Section */}
            <div className="bg-slate-800/50 backdrop-blur-sm border border-slate-700/50 rounded-2xl p-6 hover:border-emerald-500/30 transition-all">
              <h3 className="text-lg font-semibold text-white mb-4">Purchase Details</h3>

              {/* Quantity Selector */}
              <div className="mb-4">
                <label className="block text-sm font-medium text-slate-300 mb-2">
                  Quantity (kg)
                </label>
                <div className="flex items-center space-x-3">
                  <button
                    onClick={() => handleQuantityChange(quantity - 100)}
                    className={`w-10 h-10 rounded-lg flex items-center justify-center transition-colors ${quantity <= item.minQuantity
                      ? 'bg-slate-700/30 text-slate-600 cursor-not-allowed'
                      : 'bg-slate-700/50 hover:bg-slate-700/70 text-white'
                      }`}
                    disabled={quantity <= item.minQuantity}
                  >
                    -
                  </button>
                  <input
                    type="number"
                    value={quantity}
                    onChange={(e) => handleQuantityChange(parseInt(e.target.value) || item.minQuantity)}
                    min={item.minQuantity}
                    max={item.availableQuantity}
                    className="flex-1 text-center py-2 px-3 bg-slate-700/30 border border-slate-600 rounded-lg focus:outline-none focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 text-white"
                  />
                  <button
                    onClick={() => handleQuantityChange(quantity + 100)}
                    className={`w-10 h-10 rounded-lg flex items-center justify-center transition-colors ${quantity >= item.availableQuantity
                      ? 'bg-slate-700/30 text-slate-600 cursor-not-allowed'
                      : 'bg-slate-700/50 hover:bg-slate-700/70 text-white'
                      }`}
                    disabled={quantity >= item.availableQuantity}
                  >
                    +
                  </button>
                </div>
                <p className="text-xs text-slate-400 mt-1">
                  Min: {item.minQuantity}kg | Max: {item.availableQuantity}kg
                </p>
              </div>

              {/* Price Breakdown */}
              <div className="bg-slate-700/30 rounded-xl p-4 mb-4 border border-slate-600/50">
                <div className="space-y-2">
                  <div className="flex justify-between text-sm text-slate-300">
                    <span>Price ({quantity}kg × ₹{item.price})</span>
                    <span>₹{totalPrice.toLocaleString()}</span>
                  </div>
                  <div className="flex justify-between text-sm text-slate-300">
                    <span>Delivery Charges</span>
                    <span className={deliveryCharge === 0 ? 'text-emerald-400' : ''}>
                      {deliveryCharge === 0 ? 'FREE' : `₹${deliveryCharge}`}
                    </span>
                  </div>
                  <div className="border-t border-slate-600/50 pt-2">
                    <div className="flex justify-between font-semibold text-lg">
                      <span className="text-slate-300">Total</span>
                      <span className="text-emerald-400">₹{(totalPrice + deliveryCharge).toLocaleString()}</span>
                    </div>
                  </div>
                </div>
              </div>

              {/* Action Buttons */}
              <div className="space-y-3">
                <button
                  onClick={() => onPurchase?.(item, quantity)}
                  className="w-full bg-gradient-to-r from-green-500 to-emerald-600 hover:from-green-600 hover:to-emerald-700 text-white py-3 px-4 rounded-xl font-semibold transition-all transform hover:scale-105 flex items-center justify-center"
                >
                  <ShoppingCart className="w-5 h-5 mr-2" />
                  Purchase Now
                </button>

                <button
                  onClick={() => onInquire?.(item)}
                  className="w-full bg-slate-700/50 hover:bg-slate-700/70 text-white border border-slate-600 py-3 px-4 rounded-xl font-semibold transition-colors flex items-center justify-center"
                >
                  <MessageCircle className="w-5 h-5 mr-2" />
                  Send Inquiry
                </button>
              </div>

              {/* Warning */}
              <div className="mt-4 p-3 bg-yellow-900/30 border border-yellow-800/50 rounded-lg">
                <div className="flex items-start">
                  <AlertTriangle className="w-4 h-4 text-yellow-400 mt-0.5 mr-2 flex-shrink-0" />
                  <div className="text-xs text-yellow-200">
                    <strong>Important:</strong> Always verify material quality before large purchases. Request samples for bulk orders.
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ScrapDetailPage;