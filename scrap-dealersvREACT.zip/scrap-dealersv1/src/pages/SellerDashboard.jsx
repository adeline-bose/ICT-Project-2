import { Upload, Trash2, Edit, HardHat, Cpu, Battery, Cable, Car, Scissors, Plus } from 'lucide-react';
import { useState } from 'react';

const SellerDashboard = () => {
  const [listings, setListings] = useState([
    {
      id: 1,
      title: "Copper Wiring",
      type: "metal",
      weight: "25kg",
      price: "$8.50/kg",
      status: "Active",
      image: "🔌",
      gradient: "from-orange-500 to-amber-600"
    },
    {
      id: 2,
      title: "Aluminum Cans",
      type: "metal",
      weight: "15kg",
      price: "$1.20/kg",
      status: "Sold",
      image: "🥫",
      gradient: "from-blue-500 to-cyan-600"
    }
  ]);

  const [formData, setFormData] = useState({
    title: "",
    type: "",
    weight: "",
    description: "",
    image: null
  });

  const scrapTypes = [
    { value: "metal", label: "Metal", icon: <HardHat className="w-5 h-5" /> },
    { value: "electronics", label: "Electronics", icon: <Cpu className="w-5 h-5" /> },
    { value: "batteries", label: "Batteries", icon: <Battery className="w-5 h-5" /> },
    { value: "wires", label: "Wires", icon: <Cable className="w-5 h-5" /> },
    { value: "automotive", label: "Automotive", icon: <Car className="w-5 h-5" /> },
    { value: "other", label: "Other", icon: <Scissors className="w-5 h-5" /> }
  ];

  const handleSubmit = (e) => {
    e.preventDefault();
    const gradients = [
      "from-orange-500 to-amber-600",
      "from-blue-500 to-cyan-600",
      "from-purple-500 to-indigo-600",
      "from-green-500 to-emerald-600",
      "from-red-500 to-pink-600",
      "from-yellow-500 to-amber-600"
    ];
    
    const newListing = {
      id: listings.length + 1,
      title: formData.title,
      type: formData.type,
      weight: formData.weight,
      price: "Pending",
      status: "Active",
      image: formData.image ? URL.createObjectURL(formData.image) : "📦",
      gradient: gradients[Math.floor(Math.random() * gradients.length)]
    };
    setListings([...listings, newListing]);
    setFormData({
      title: "",
      type: "",
      weight: "",
      description: "",
      image: null
    });
  };

  const handleDelete = (id) => {
    setListings(listings.filter(item => item.id !== id));
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-blue-900 to-emerald-900">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="flex items-center justify-between mb-8">
          <h1 className="text-3xl font-bold text-white">Seller Dashboard</h1>
          <div className="flex items-center space-x-4">
            <div className="bg-emerald-500/20 text-emerald-300 px-4 py-2 rounded-lg font-medium">
              {listings.length} Active Listings
            </div>
          </div>
        </div>
        
        <div className="grid lg:grid-cols-2 gap-8">
          {/* Listing Form */}
          <div className="bg-slate-800/50 backdrop-blur-sm border border-slate-700/50 rounded-2xl p-6 hover:border-emerald-500/30 transition-all">
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-xl font-semibold text-white">List New Scrap</h2>
              <div className="w-10 h-10 bg-emerald-500/20 rounded-lg flex items-center justify-center text-emerald-300">
                <Plus className="w-5 h-5" />
              </div>
            </div>
            
            <form onSubmit={handleSubmit} className="space-y-6">
              <div>
                <label className="block text-sm font-medium text-slate-300 mb-1">Item Title</label>
                <input
                  type="text"
                  value={formData.title}
                  onChange={(e) => setFormData({...formData, title: e.target.value})}
                  className="w-full px-4 py-2 bg-slate-700/30 border border-slate-600 rounded-lg focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 text-white placeholder-slate-400"
                  placeholder="e.g. Copper Wiring, Aluminum Sheets"
                  required
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-slate-300 mb-1">Scrap Type</label>
                <select
                  value={formData.type}
                  onChange={(e) => setFormData({...formData, type: e.target.value})}
                  className="w-full px-4 py-2 bg-slate-700/30 border border-slate-600 rounded-lg focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 text-white"
                  required
                >
                  <option value="" className="text-slate-400">Select type</option>
                  {scrapTypes.map((type) => (
                    <option key={type.value} value={type.value} className="text-white">{type.label}</option>
                  ))}
                </select>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-slate-300 mb-1">Weight (kg)</label>
                  <input
                    type="number"
                    value={formData.weight}
                    onChange={(e) => setFormData({...formData, weight: e.target.value})}
                    className="w-full px-4 py-2 bg-slate-700/30 border border-slate-600 rounded-lg focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 text-white"
                    placeholder="0.00"
                    step="0.01"
                    required
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-300 mb-1">Upload Photo</label>
                  <label className="flex items-center justify-center w-full px-4 py-2 border-2 border-dashed border-slate-600 rounded-lg cursor-pointer hover:bg-slate-700/30 transition-colors">
                    <Upload className="w-5 h-5 mr-2 text-slate-400" />
                    <span className="text-sm text-slate-400">
                      {formData.image ? formData.image.name : "Choose file"}
                    </span>
                    <input
                      type="file"
                      onChange={(e) => setFormData({...formData, image: e.target.files[0]})}
                      className="hidden"
                      accept="image/*"
                    />
                  </label>
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-slate-300 mb-1">Description</label>
                <textarea
                  value={formData.description}
                  onChange={(e) => setFormData({...formData, description: e.target.value})}
                  rows={3}
                  className="w-full px-4 py-2 bg-slate-700/30 border border-slate-600 rounded-lg focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 text-white placeholder-slate-400"
                  placeholder="Provide details about condition, purity, etc."
                />
              </div>

              <button
                type="submit"
                className="w-full bg-gradient-to-r from-emerald-500 to-emerald-600 text-white py-3 px-6 rounded-lg font-medium hover:from-emerald-600 hover:to-emerald-700 transition-all transform hover:scale-105"
              >
                List Item
              </button>
            </form>
          </div>

          {/* Current Listings */}
          <div>
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-xl font-semibold text-white">Your Listings</h2>
              <div className="text-slate-400 text-sm">
                {listings.filter(l => l.status === "Active").length} Active • {listings.filter(l => l.status === "Sold").length} Sold
              </div>
            </div>
            
            {listings.length === 0 ? (
              <div className="bg-slate-800/50 backdrop-blur-sm border border-slate-700/50 rounded-2xl p-8 text-center hover:border-emerald-500/30 transition-all">
                <p className="text-slate-400">You haven't listed any items yet</p>
              </div>
            ) : (
              <div className="space-y-4">
                {listings.map((item) => (
                  <div 
                    key={item.id} 
                    className="bg-slate-800/50 backdrop-blur-sm border border-slate-700/50 rounded-2xl p-4 flex items-start hover:border-emerald-500/30 transition-all"
                  >
                    <div className={`w-16 h-16 rounded-lg flex items-center justify-center text-2xl mr-4 ${item.gradient} bg-gradient-to-r`}>
                      {item.image}
                    </div>
                    <div className="flex-1">
                      <div className="flex justify-between">
                        <h3 className="font-medium text-white">{item.title}</h3>
                        <span className={`px-2 py-1 text-xs rounded-full ${
                          item.status === "Active" 
                            ? "bg-emerald-500/20 text-emerald-300" 
                            : "bg-slate-700/50 text-slate-400"
                        }`}>
                          {item.status}
                        </span>
                      </div>
                      <p className="text-sm text-slate-400">{item.type} • {item.weight}</p>
                      <p className="text-sm font-medium text-emerald-400 mt-1">{item.price}</p>
                    </div>
                    <div className="flex space-x-2 ml-4">
                      <button className="p-2 text-slate-400 hover:text-emerald-400 hover:bg-slate-700/50 rounded-lg transition-colors">
                        <Edit className="w-5 h-5" />
                      </button>
                      <button 
                        className="p-2 text-slate-400 hover:text-red-400 hover:bg-slate-700/50 rounded-lg transition-colors"
                        onClick={() => handleDelete(item.id)}
                      >
                        <Trash2 className="w-5 h-5" />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default SellerDashboard;