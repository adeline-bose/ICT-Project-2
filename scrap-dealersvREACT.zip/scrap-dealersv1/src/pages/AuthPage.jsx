import React, { useState } from 'react';
import WelcomePage from '../components/AuthSection/WelcomePage';
import LoginPage from '../components/AuthSection/LoginPage';
import SignupPage from '../components/AuthSection/SignupPage';
import ConfirmationPage from '../components/AuthSection/ConfirmationPage';

const AuthController = () => {
  const [currentPage, setCurrentPage] = useState('welcome'); // welcome, login, signup, confirmation
  const [userType, setUserType] = useState('seller'); // seller, buyer

  const handleUserTypeSelect = (type) => {
    setUserType(type);
    setCurrentPage('signup');
  };

  const handleLoginSubmit = (formData) => {
    // Handle login logic here
    console.log('Login submitted:', formData);
    // You can add your authentication logic here
    // For now, we'll just log the data
  };

  const handleSignupSubmit = (data) => {
    // Handle signup logic here
    console.log('Signup submitted:', data);
    // You can add your registration logic here
    // After successful registration, show confirmation
    setCurrentPage('confirmation');
  };

  const renderCurrentPage = () => {
    switch (currentPage) {
      case 'welcome':
        return (
          <WelcomePage
            onUserTypeSelect={handleUserTypeSelect}
            onNavigateToLogin={() => setCurrentPage('login')}
          />
        );
      
      case 'login':
        return (
          <LoginPage
            onBack={() => setCurrentPage('welcome')}
            onNavigateToSignup={() => setCurrentPage('welcome')}
            onSubmit={handleLoginSubmit}
          />
        );
      
      case 'signup':
        return (
          <SignupPage
            userType={userType}
            onBack={() => setCurrentPage('welcome')}
            onNavigateToLogin={() => setCurrentPage('login')}
            onSubmit={handleSignupSubmit}
          />
        );
      
      case 'confirmation':
        return (
          <ConfirmationPage
            onNavigateToLogin={() => setCurrentPage('login')}
            onNavigateToHome={() => setCurrentPage('welcome')}
          />
        );
      
      default:
        return (
          <WelcomePage
            onUserTypeSelect={handleUserTypeSelect}
            onNavigateToLogin={() => setCurrentPage('login')}
          />
        );
    }
  };

  return renderCurrentPage();
};

export default AuthController;