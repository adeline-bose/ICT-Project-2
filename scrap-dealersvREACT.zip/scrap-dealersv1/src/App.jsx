import { Route, Routes } from 'react-router-dom'
import ScrapSmartHomepage from './pages/Home'
import AuthController from './pages/AuthPage'
import ScrapDetailPage from './pages/ScrapDetailPage'
import SellerDashboard from './pages/SellerDashboard'
import ScrapListingsPage from './pages/ScrapListing'

function App() {

  return (
    <>
      <Routes>
        <Route path='/' element={<ScrapSmartHomepage></ScrapSmartHomepage>}></Route>
        <Route path='/auth' element={<AuthController></AuthController>}></Route>
        <Route path='/scrap-details' element={<ScrapDetailPage></ScrapDetailPage>}></Route>
        <Route path='/seller' element={<SellerDashboard></SellerDashboard>}></Route>
        <Route path='/buyer' element={<ScrapListingsPage></ScrapListingsPage>}></Route>
      

      </Routes>
    </>
  )
}

export default App
